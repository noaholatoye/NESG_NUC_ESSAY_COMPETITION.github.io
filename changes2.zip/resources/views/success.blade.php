@extends('layouts.main')

@section('content')
    <div class="container">
        <div class="row">
            <div class="col-md-6 col-lg-6 col-xs-12 col-sm-12">
                <img src="public/img/good_job.jpg" class="img-responsive">
            </div>
            
            <div class="col-md-6 col-lg-6 col-xs-12 col-sm-12">
                <div class="container">
                    <h2>Good Job! You have successfully submitted your entry. You will be notified when the shortlist is made available</h2>
                </div>
            </div>
        </div>
    </div>
@endsection