<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class entries extends Model
{
    //
}
