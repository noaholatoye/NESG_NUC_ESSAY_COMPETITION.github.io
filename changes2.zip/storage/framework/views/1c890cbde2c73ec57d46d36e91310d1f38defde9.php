<nav>
    <div class="topnav" id="myTopnav">
        <div class="active">
            <a href="<?php echo e(route('pages.index')); ?>"
                ><img
                    src="<?php echo e(asset('public/svg/nesg_logo.svg')); ?>"
                    style="width: 200px; height: 50px; margin: 0;"
                    alt="NESG Logo"
            /></a>
        </div>
        <a class="link" href="#criteria">CRITERIA</a>
        <a class="link" href="#form">APPLY</a>
        <a class="link" href="#download">DOWNLOAD INSTRUCTION</a>
        <?php if(auth()->guard()->guest()): ?>
            <a class="link" href="submit.html">Register to Apply</a>            
        <?php else: ?>
            <a class="link" href="#">SUBMIT ENTRY</a>
        
        <?php endif; ?>
        <a class="link" href="mailto: info@nesgroup.org">CONTACT</a>
        <a href="javascript:void(0);" class="icon" onclick="myFunction()">
            <i class="fa fa-bars"></i>
        </a>
    </div>
</nav><?php /**PATH C:\xampp\htdocs\essay\resources\views/layouts/header.blade.php ENDPATH**/ ?>