<?php $__env->startSection('content'); ?>
<div class="main-content">
    <section class="img-container">
        <div class="header">
            <div class="header-infographic"></div>
            <h1>
                Enhancing confidence in Nigeria for Nation Building A long march
                towards economic success and improved quality of life for Nigerians
            </h1>
            <p>
                Eligibility: Entrants must be undergraduates of Nigerian
                Universities
            </p>
        </div>
    </section>
    <!-- img container -->
    <section id="about" class="about-container">
        <h2>Dual Registration Alert!</h2>
        <center>
            <p>
                <?php echo e($user); ?> It would seem that you have already registered! Procced to the home page to submit your entry.
            </p>
        </center>
    </section>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\essay\resources\views/already_registered.blade.php ENDPATH**/ ?>