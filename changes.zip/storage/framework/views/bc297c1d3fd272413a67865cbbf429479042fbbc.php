<?php $__env->startSection('content'); ?>
<div class="main-content">
    <section class="img-container">
        <div class="header">
            <div class="header-infographic"></div>
            <h1>
                Enhancing confidence in Nigeria for Nation Building A long march
                towards economic success and improved quality of life for Nigerians
            </h1>
            <p>
                Eligibility: Entrants must be undergraduates of Nigerian
                Universities
            </p>
        </div>
    </section>
    <!-- img container -->
    <section id="about" class="about-container">
        <h2>About the Competition!</h2>
        <p>
            The Nigerian Economic Summit Group (NESG) in partnership with the
            Nigerian Universities Commission (NUC) is pleased to announce the
            theme for the Nigerian economic summit (NES) 25th Anniversary Essay
            Competition-
        </p>
        <h1>
            "Enhancing confidence in Nigeria for Nation Building A long march
            towards economic success and improved quality of life for Nigerians"
        </h1>
        <div>
            <div class="description">
                <p>
                    “Trust is the social glue that holds families, communities,
                    organizations and societies together; without it, reaching any
                    agreement can become a fraught negotiation.” – Peggy (Rockefeller)
                    Dulany, Synergos1 With a global shift towards ‘inclusive’ economic
                    growth, it is argued that economic prosperity and business success
                    cannot be adequately explained by abundance of natural resources,
                    brilliance of intellect, or the presence of good laws and
                    institutions. Rather, economic prosperity requires (in addition to
                    the above elements listed) a culture of trust and social capital
                    that forms an economic input (Fukuyama, 1995). <br />
                    <br />In the light of woes that have perpetually plagued the
                    Nigerian economy despite being the largest African economy,
                    Nigeria has remained a low-trust country and this has resulted in
                    a slow-paced growth. With an outlook of building a nation that is
                    competitive and sustainable, Nigeria sets to embark on the long
                    march towards economic growth and improved quality of life for its
                    people. Bearing in mind the highly diverse nature of Nigeria, we
                    cannot therefore shy away from the arduous task of rebuilding
                    trust and confidence in her people. It is on this premise that the
                    NESG calls for applicants for the essay competition.
                </p>
            </div>
        </div>
    </section>
    <?php if(auth()->guard()->guest()): ?>
    <!-- about-container -->
    <section class="criteria-container" id="criteria">
        <h2>Application Criteria</h2>
        <div class="criteria-info-wrapper">
            <div class="circle-1">
                <div class="inner-circle">
                    <img src="<?php echo e(asset('public/svg/light_icon.svg')); ?>" alt="light Illustration" />
                    <p>Entries must be written in English</p>
                </div>
            </div>
            <div class="circle-2">
                <div class="inner-circle">
                    <img src="<?php echo e(asset('public/svg/entry_icon.svg')); ?>" alt="Book Illustration" />
                    <p>One entry per participant</p>
                </div>
            </div>
            <div class="circle-3">
                <div class="inner-circle">
                    <img src="<?php echo e(asset('public/svg/target_icon.svg')); ?>" alt="Target Illustration" />
                    <p>1,500 maximum word count</p>
                </div>
            </div>
            <div class="circle-4">
                <div class="inner-circle">
                    <img src="<?php echo e(asset('public/svg/setting_icon.svg')); ?>" alt="Setting Illustration" />
                    <p>Plagiarism is not accepted</p>
                </div>
            </div>
            <div class="circle-5">
                <div class="inner-circle">
                    <img src="<?php echo e(asset('public/svg/time_icon.svg')); ?>" alt="Timeline Illustration" />
                    <p>Submitted before July 24, April 2019</p>
                </div>
            </div>
        </div>
    </section>
    <!-- criteria-container -->
    <section class="prizes-container" id="prizes">
        <div class="prize-details">
            <h2>Top 3 Biggest Prizes</h2>
            <div class="prize-list">
                <div class="prize-1">
                    Internship at the NESG | Prestigious certificate of performance
                </div>
                <div class="prize-2">
                    All expense paid trip to 25th Nigerian Economic Summit in Abuja,
                    October 2019
                </div>
                <div class="prize-3">
                    Essay presentation to an audience of top public/private officials
                </div>
            </div>
            <button>Download Instruction</button>
        </div>
    </section>
    <!-- prizes container -->
    <section class="form-container" id="form">
        <div class="form-details">

            <center>
                <h3></h3>
            </center>
                <div class="tab" style="padding: 5px!important;">
                    <button style="width: 50%!important; color:white!important;" onclick="openCity(event, 'London')" id="defaultOpen">Register Here</button>
                    <button style="width: 50%!important; color:white!important;" onclick="openCity(event, 'Paris')">Have you registered earlier? Submit Entry Here</button>
                </div>

                <div id="London" class="tabcontent">
                    <form action="<?php echo e(route('register_users')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <fieldset class="row-1">
                            <legend><span class="number">1</span> Your basic info</legend>
                            <h3>
                                Please make sure you have read the <strong>criteria </strong>
                                before proceeding to apply
                            </h3>
                            <div class="input-wrapper">
                                <div class="name-col">
                                    <label for="fullName">Full Name:</label>
                                    <input type="text" id="fullName" name="name" placeholder="Your full name.." required />
                                </div>
                                <div class="email-col">
                                    <label for="email">Email:</label>
                                    <input type="email" id="email" name="email" placeholder="name@example.com.." required />
                                </div>
                                <div class="gender-col">
                                    <label for="gender">Gender:</label>
                                    <input type="text" id="gender" name="gender" placeholder="Male/Female.." required />
                                </div>
        
                                <div class="phone-col">
                                    <label for="phone">Phone:</label>
                                    <input type="number" id="phone" name="phone" placeholder="080.." required />
                                </div>
                                <div class="date-col">
                                    <label for="date">Date of Birth:</label>
                                    <input type="date" id="date" name="dob" placeholder="dd/mm/yy" required />
                                </div>
                                <div class="university-col">
                                    <label for="university">University:</label>
                                    <input type="text" id="university" name="university"
                                        placeholder="Full name (University of Lagos).." required />
                                </div>
                                <div class="department-col">
                                    <label for="department">Department:</label>
                                    <input type="text" id="department" name="department" placeholder="Computer Science.."
                                        required />
                                </div>
                                <div class="level-col">
                                    <label for="level">Level:</label>
                                    <input type="number" id="level" name="level" placeholder="100.." required />
                                </div>
                                <div class="matric-col">
                                    <label for="matric">Matric Number:</label>
                                    <input type="text" id="matric" name="matric_no" placeholder="1210.." required />
                                </div>
                            </div>
                            <!-- input-wrapper -->
                        </fieldset>
                        <!-- row-1 -->
                        <button type="submit"><?php echo e(__('Register')); ?></button>
                    </form>
                </div>

                <div id="Paris" class="tabcontent">
                    <p>Please enter these credentials to verify if you have previously registered.</p>
                    <form method="POST" action="<?php echo e(route('login')); ?>">
                        <?php echo csrf_field(); ?>

                        <div class="form-group row">
                            <label for="email"
                                class="col-md-4 col-form-label text-md-right">Registeration Email</label>

                            <div class="col-md-6">
                                <input id="email" type="email" class="form-control <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>"
                                    name="email" value="<?php echo e(old('email')); ?>" required autocomplete="email" autofocus>

                                <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="password"
                                class="col-md-4 col-form-label text-md-right">Registeration Phone number</label>

                            <div class="col-md-6">
                                <input id="password" type="password"
                                    class="form-control <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="password"
                                    required autocomplete="current-password">

                                <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                            </div>
                        </div>

                        <div class="form-group row">
                            <div class="col-md-6 offset-md-4">
                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox" name="remember" id="remember"
                                        <?php echo e(old('remember') ? 'checked' : ''); ?>>

                                    <label class="form-check-label" for="remember">
                                        <?php echo e(__('Remember Me')); ?>

                                    </label>
                                </div>
                            </div>
                        </div>

                        <div class="form-group row mb-0">
                            <div class="col-md-8 offset-md-4">
                                <button type="submit" class="btn btn-primary">
                                    Proceed to Submit entry
                                </button>
                                
                            </div>
                        </div>
                    </form>
                </div>
                <?php else: ?>

                    <?php if($has_user_submitted == 0): ?>
                        <form name="myForm" action="<?php echo e(route('submit_essay')); ?>" method="post" style="padding-top:120px;"
                        onsubmit="return validateForm()">
                        <?php echo csrf_field(); ?>
                            <fieldset class="row-2">
                                <center><legend><span class="number">2</span> Welcome back <?php echo e($current_user->name); ?>, submit your entry</legend></center>
                                
                                <div class="textarea">
                                    <label for="about-textarea">About you (100 words)</label>
                                    <textarea name="about_textarea" id="about-textarea" cols="50" rows="5" required
                                        placeholder="Enter text here..."></textarea>
                                </div>
                                <div class="textarea">
                                    <label for="summary-textarea">Essay Summary (100 words)</label>
                                    <textarea name="summary_textarea" id="summary-textarea" cols="50" rows="5"
                                        placeholder="Enter text here..." required></textarea>
                                </div>
                                <div class="textarea">
                                    <label for="essay-textarea">Paste Essay (1500 words)</label>
                                    <textarea name="essay_textarea" id="essay-textarea" cols="50" rows="10"
                                        placeholder="Enter text here..." required></textarea>
                                </div>
                                <label class="file">
                                    <input type="file" id="file" aria-label="File browser example" name="image" />
                                    <span class="file-custom"></span>
                                </label>
                            </fieldset>
                            <button type="submit">Submit</button>
                        </form>
                    <?php else: ?>
                        <center>
                            <h1>Hello <?php echo e($current_user->name); ?>, You have already submitted an entry. You will be notified if shortlisted. Cheers!</h1>
                        </center>
                    <?php endif; ?>
                    
                <?php endif; ?>
        </div>
        <!-- form details -->
    </section>
    <!-- form container -->
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\essay\resources\views/index.blade.php ENDPATH**/ ?>