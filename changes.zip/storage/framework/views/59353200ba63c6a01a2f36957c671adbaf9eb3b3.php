<!DOCTYPE html>
    <html lang="en-US">
    	<head>
    		<meta charset="utf-8">
    	</head>
    	<body>
    		<h2>Test Email</h2>
    		
    	</body>
    </html><?php /**PATH C:\xampp\htdocs\essay\resources\views/emails/test.blade.php ENDPATH**/ ?>