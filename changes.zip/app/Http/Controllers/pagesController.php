<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash; 
use Illuminate\Support\Facades\Auth;
use App\User;
use App\entries;

use App\Mail\testEmail;

class pagesController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $current_user = Auth::user();
        $has_user_submitted = entries::where('user_id', Auth::id())->count();

        return view('index', compact('current_user','has_user_submitted'));
    }

    public function success()
    {
        return view('success');
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function sendmail(){
            $data = ['message' => 'This is a test'];
            \Mail::to('iconstechsystems@gmail.com')->send(new testEmail($data));

            return view('mail_success');
    }
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
               
        $add_users = new user;
        $add_users->name = $request->name;
        $add_users->email = $request->email;
        $add_users->gender = $request->gender;
        $add_users->password = Hash::make($request->phone);
        $add_users->department = $request->department;
        $add_users->dob = $request->dob;
        $add_users->phone = $request->phone;
        $add_users->university = $request->university;
        $add_users->matric_no = $request->matric_no;
        //$add_users->password = $request->password;
        $add_users->level = $request->level;
       // $add_users->essay = $request->essay;
        
        $add_users->save();
        return view('index');
        

        //return 'file uploaded';
        
    }

    public function submit_essay(Request $request)
    {
        $this->validate( $request, [
            'image' => 'image|nullable|max:1999' 
         ]);
 
         //handle file upload
         if( $request->hasFile('image')){
             // get filename with extensio
             $filenamewithext = $request->file('image')->getClientOriginalName();
             //get just file name
             $filename = pathinfo($filenamewithext, PATHINFO_FILENAME);
             //get just ext
             $extension = $request->file('image')->getClientOriginalExtension();
             //filename to store
             $file_name_to_store = $filename.'_'.time().'.'.$extension;
             //upload image
             $path = $request->file('image')->storeAs('public/profile_images', $file_name_to_store);
         } else {
             $file_name_to_store = 'noimage.jpg';
         }

        $add_entries = new entries;
        $add_entries->user_id = Auth::id();
        $add_entries->user_profile = $request->about_textarea;
        $add_entries->essay_summary = $request->summary_textarea;
        $add_entries->essay = $request->essay_textarea;
        $add_entries->profile_picture = $file_name_to_store;
       
        
        $add_entries->save();
        return view('index')->withSuccess('Your entry has been successfully submitted. Do not attempt to submit twice. You will recieve an email notification');
        

        //return 'file uploaded';
        
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
