@extends('layouts.main')

@section('content')
<!-- Masthead -->
<header class="masthead" style="background-color: rgba(0,0,0,0.5)!important;">
    <div class="container h-100">
        <div class="row h-100 align-items-center justify-content-center text-center">
            <div class="col-lg-10 align-self-end">
                <h1 class="text-uppercase text-white font-weight-bold">"Improving Confidence in Nigeria for Nation
                    building:
                </h1>
                <hr class="divider my-4">
            </div>
            <div class="col-lg-8 align-self-baseline">
                <h4 class="text-uppercase text-white font-weight-bold">towards economic success and improved quality
                    of life for Nigerians"
                </h4>
                <a class="btn btn-primary btn-xl js-scroll-trigger" href="#about">Find Out More</a>
            </div>
        </div>
    </div>
</header>

<!-- About Section -->
<section class="page-section bg-primary" id="about">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-lg-8 text-center">
                <h2 class="text-white mt-0">About the Competition!</h2>
                <hr class="divider light my-4">
                <p class="text-white-50 mb-4" style="text-align: justify; color: white!important;">The Nigerian Economic
                    Summit Group (NESG) in partnership with the Nigerian Universities Commission (NUC) is pleased to
                    announce the theme for the Nigerian economic summit (NES) 25th Anniversary Essay Competition- "
                </p>
                <h2 class="text-white-50 mb-4" style="text-align: justify; color: white!important;"><strong>Improving
                        Confidence in Nigeria for Nation building: towards economic success and improved quality of life
                        for Nigerians"</strong></h2>
                <p class="text-white-50 mb-4" style="text-align: justify; color: white!important;">
                    “Trust is the social glue that holds families, communities, organizations and societies together;
                    without it, reaching any agreement can become a fraught negotiation.” – Peggy (Rockefeller) Dulany,
                    Synergos1

                    With a global shift towards ‘inclusive’ economic growth, it is argued that economic prosperity and
                    business success cannot be adequately explained by abundance of natural resources, brilliance of
                    intellect, or the presence of good laws and institutions. Rather, economic prosperity requires (in
                    addition to the above elements listed) a culture of trust and social capital that forms an economic
                    input (Fukuyama, 1995).

                    <br><br>In the light of woes that have perpetually plagued the Nigerian economy despite being the
                    largest African economy, Nigeria has remained a low-trust country and this has resulted in a
                    slow-paced growth.

                    With an outlook of building a nation that is competitive and sustainable, Nigeria sets to embark on
                    the long march towards economic growth and improved quality of life for its people. Bearing in mind
                    the highly diverse nature of Nigeria, we cannot therefore shy away from the arduous task of
                    rebuilding trust and confidence in her people. It is on this premise that the NESG calls for
                    applicants for the essay competition.</p>
                <a class="btn btn-light btn-xl js-scroll-trigger" href="#apply">Apply!</a>
            </div>
        </div>
    </div>
</section>

<!-- Services Section -->
<section class="page-section" id="criteria">
    <div class="container">
        <h2 class="text-center mt-0">Application Criteria</h2>
        <hr class="divider my-4">
        <div class="row">
            <div class="col-lg-12 col-sm-12">
                <ul style="list-style:none; line-height: 35px;">
                    <li><i class="fa fa-check-square"></i> Entrants must be Nigerians</li>
                    <li><i class="fa fa-check-square"></i> Entrants must be undergraduates of Nigerian Universities;
                    </li>
                    <li><i class="fa fa-check-square"></i> Entries must be written in English Language and be the
                        original work of the writer</li>
                    <li><i class="fa fa-check-square"></i> Only one entry per participant is allowed. Please carefully
                        review your essay before submitting, you cannot edit after submission;</li>
                    <li><i class="fa fa-check-square"></i> The maximum word count is 1,500 words;</li>
                </ul>
            </div>
        </div>
    </div>
</section>



<!-- Call to Action Section -->
<section class="page-section bg-dark text-dark" id="apply">
    <div class="container">
        <h2 class="mb-4 text-center text-white">Please make sure you have read the <a href="#criteria">criteria</a>
            before
            proceeding to apply</h2>
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-md-12">
                    <div class="card">
                        <div class="card-header">{{ __('Register') }}</div>

                        <div class="card-body">
                            @if (session()->has('success'))
                            <div class="alert alert-success alert-dismissible fade show" role="alert">
                                <strong>Your entry has been uploaded successfully! You will be notified on future
                                    proceedings via the email you provided</strong>
                                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                            @else
                            <form method="POST" action="{{ route('register_entries') }}" enctype="multipart/form-data">
                                @csrf

                                <div class="form-group row">
                                    <label for="name"
                                        class="col-md-3 col-form-label text-md-right">{{ __('Name') }}</label>

                                    <div class="col-md-9">
                                        <input id="name" type="text"
                                            class="form-control @error('name') is-invalid @enderror" name="name"
                                            value="{{ old('name') }}" required autocomplete="name" autofocus>

                                        @error('name')
                                        <span class="invalid-feedback" role="alert">
                                            <strong>{{ $message }}</strong>
                                        </span>
                                        @enderror
                                    </div>
                                </div>

                                <div class="form-group row">
                                    <label for="email"
                                        class="col-md-3 col-form-label text-md-right">{{ __('E-Mail Address') }}</label>

                                    <div class="col-md-9">
                                        <input id="email" type="email"
                                            class="form-control @error('email') is-invalid @enderror" name="email"
                                            value="{{ old('email') }}" required autocomplete="email">

                                        @error('email')
                                        <span class="invalid-feedback" role="alert">
                                            <strong>{{ $message }}</strong>
                                        </span>
                                        @enderror
                                    </div>
                                </div>

                                <div class="form-group row">
                                    <label for="password"
                                        class="col-md-3 col-form-label text-md-right">{{ __('Password') }}</label>

                                    <div class="col-md-9">
                                        <input id="password" type="password"
                                            class="form-control @error('password') is-invalid @enderror" name="password"
                                            required autocomplete="new-password">

                                        @error('password')
                                        <span class="invalid-feedback" role="alert">
                                            <strong>{{ $message }}</strong>
                                        </span>
                                        @enderror
                                    </div>
                                </div>

                                <div class="form-group row">
                                    <label for="password-confirm"
                                        class="col-md-3 col-form-label text-md-right">{{ __('Confirm Password') }}</label>

                                    <div class="col-md-9">
                                        <input id="password-confirm" type="password" class="form-control"
                                            name="password_confirmation" required autocomplete="new-password">
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label class="col-md-3 col-form-label text-md-right">Date of Birth</label>
                                    <div class="col-md-9 col-lg-9">
                                        <input type="date" name="dob" class="form-control">
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label class="col-md-3 col-form-label text-md-right">Phone</label>
                                    <div class="col-md-9 col-lg-9">
                                        <input type="text" name="phone" class="form-control" required>
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label class="col-md-3 col-form-label text-md-right">University</label>
                                    <div class="col-md-9 col-lg-9">
                                        <input type="text" name="university" class="form-control" required>
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label class="col-md-3 col-form-label text-md-right">Matric Number</label>
                                    <div class="col-md-9 col-lg-9">
                                        <input type="text" name="matric_no" class="form-control" required>
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label for="address" class="col-md-3 col-form-label text-md-right">Address</label>
                                    <div class="col-md-9 col-lg-9">
                                        <textarea name="address" class="form-control" required></textarea>
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label for="address" class="col-md-3 col-form-label text-md-right">Tell us a little
                                        about yourself in 100 words</label>
                                    <div class="col-md-9 col-lg-9">
                                        <textarea name="profile" class="form-control" rows="10" required
                                            maxlength="100"></textarea>
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label for="summary" class="col-md-3 col-form-label text-md-right">In 100 words,
                                        write a summary of your essay</label>
                                    <div class="col-md-9 col-lg-9">
                                        <textarea name="summary" class="form-control" rows="10" required
                                            maxlength="100"></textarea>
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label for="essay" class="col-md-3 col-form-label text-md-right">In not more than
                                        1500 words, paste your essay here</label>
                                    <div class="col-md-9 col-lg-9">
                                        <textarea name="essay" class="form-control" rows="40" required
                                            maxlength="1500"></textarea>
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label for="profile_image" class="col-md-3 col-form-label text-md-right">Upload
                                        Profile Picture</label>
                                    <div class="col-md-9 col-lg-9">
                                        <input type="file" name="profile_image" class="form-control" accept="image/*">
                                    </div>
                                </div>
                                <div class="form-group row mb-0">
                                    <div class="col-md-12">
                                        <button type="submit" class="btn btn-primary btn-block">
                                            {{ __('Register') }}
                                        </button>
                                    </div>
                                </div>
                            </form>
                            @endif

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Contact Section -->
<section class="page-section" id="contact">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-lg-8 text-center">
                <h2 class="mt-0">Let's Get In Touch!</h2>
                <hr class="divider my-4">
                <p class="text-muted mb-5">If you have any questions, Kindly forward them to the email below and we'd be
                    sure to reply you as soon as possible.</p>
            </div>
        </div>
        <div class="row">

            <div class="col-lg-12 mr-auto text-center">
                <i class="fas fa-envelope fa-3x mb-3 text-muted"></i>
                <!-- Make sure to change the email address in anchor text AND the link below! -->
                <a class="d-block" href="mailto:info@nesgroup.org">info@nesgroup.org</a>
            </div>
        </div>
    </div>
</section>
@endsection
