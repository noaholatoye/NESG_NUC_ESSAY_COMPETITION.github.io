<!-- Navigation -->
<nav class="navbar navbar-expand-lg navbar-light fixed-top py-3" id="mainNav">
    <div class="container">
        <a class="navbar-brand js-scroll-trigger" href="{{ url('/') }}"><img src="public/img/download.jpg"
                alt="Essay Logo" style="width: 100px; height: auto;"></a>
        <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse"
            data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false"
            aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarResponsive">
            <ul class="navbar-nav ml-auto my-2 my-lg-0">
                <li class="nav-item">
                    <a class="nav-link js-scroll-trigger" href="#about">About</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link js-scroll-trigger" href="#criteria">Criteria</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link js-scroll-trigger" href="#apply">Apply</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link js-scroll-trigger" href="#contact">Contact</a>
                </li>
                <li class="nav-item">
                    <!-- Example split danger button -->
                    <div class="btn-group">
                        <button type="button" class="btn btn-success"><i class="fa fa-lock"></i></button>
                        <button type="button" class="btn btn-success dropdown-toggle dropdown-toggle-split"
                            data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            <span class="sr-only">Toggle Dropdown</span>
                        </button>
                        <div class="dropdown-menu">
                            @guest

                                <a class="nav-link" style="color: green;" href="{{ route('login') }}">{{ __('Login') }}</a>

                            @if (Route::has('register'))

                                <a class="nav-link" style="color: green;" href="{{ route('register') }}">{{ __('Register') }}</a>

                            @endif
                            @else
                                <a class="dropdown-item" href="{{ route('logout') }}" onclick="event.preventDefault();
                                                            document.getElementById('logout-form').submit();">
                                    {{ __('Logout') }}
                                </a>

                            <form id="logout-form" action="{{ route('logout') }}" method="POST" style="display: none;">
                                @csrf
                            </form>

                            @endguest
                        </div>
                </li>
            </ul>
        </div>
    </div>
</nav>
